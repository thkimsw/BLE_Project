package com.example.bt_app;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseSettings;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.BeaconTransmitter;

import java.util.Arrays;

public class MainActivity extends Activity {
    EditText Major, Minor, tx_interval;
    Button start, stop, exit, Txbtn, test;
    BeaconParser beaconParser;
    Beacon beacon;
    BeaconTransmitter beaconTransmitter;
    TextView state, s_tx;
    String uuid = "2e234454-cf6d-4a0f-adf2-f4911ba9ffa6";
    String major_v = "1", minor_v = "2";
    int TxPower = -59, tx_inter = 0;
    private static int REQUEST_ENABLE_BT = 1001;
    public static BluetoothManager bluetoothManager;
    public BluetoothAdapter mBluetoothAdapter;
    int t = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(this, loading.class);
        startActivity(intent);

        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }

        start = findViewById(R.id.start);
        stop = findViewById(R.id.stop);
        exit = findViewById(R.id.exit);
        state = findViewById(R.id.state);
        Txbtn = findViewById(R.id.Txbtn);
        s_tx = findViewById(R.id.s_tx);
        Major = findViewById(R.id.Major);
        Minor = findViewById(R.id.Minor);
        test = findViewById(R.id.test);
        tx_interval = findViewById(R.id.tx_interval);
        /*
        beacon.setExtraDataFields(
        );
        beacon.setPacketCount();
         */


        final Handler handler = new Handler() {

            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                Log.e("beacon", "undoing advertising");
                try {
                    beacon = new Beacon.Builder()
                            .setId1(uuid)//uuid 8-4-4-4-12
                            .setId2(major_v)
                            .setId3(minor_v)
                            .setManufacturer(0x0118) // Radius Networks.  Change this for other beacon layouts  ibeacon setup
                            .setTxPower(TxPower)  //-59 -65 -69 -72 -77 -81 -84 -115
                            .setDataFields(Arrays.asList(new Long[]{0l})) // Remove this for beacon layouts without d: fields
                            .build();
                    beaconParser = new BeaconParser()
                            .setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24");  //포맷 중요
                    beaconTransmitter = new BeaconTransmitter(getApplicationContext(), beaconParser);
                    if (beaconTransmitter.isStarted() == true) {
                        beaconTransmitter.startAdvertising(beacon, new AdvertiseCallback() {
                            @Override
                            public void onStartFailure(int errorCode) {
                                Log.e("", "Advertisement start failed with code: " + errorCode);
                            }

                            @Override
                            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                                Log.i("", "Advertisement start succeeded.");
                            }
                        });
                        major_v = Major.getText().toString();
                        minor_v = Minor.getText().toString();
                        Major.setText("Major : " + major_v);
                        Minor.setText("Minor : " + minor_v);
                        state.setText("비콘송신중");

                    } else {
                        beaconTransmitter.startAdvertising(beacon, new AdvertiseCallback() {
                            @Override
                            public void onStartFailure(int errorCode) {
                                Log.e("", "Advertisement start failed with code: " + errorCode);
                            }

                            @Override
                            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                                Log.i("", "Advertisement start succeeded.");
                            }
                        });

                        major_v = Major.getText().toString();
                        minor_v = Minor.getText().toString();
                        Major.setText(major_v);
                        Minor.setText(minor_v);
                        state.setTextSize(12);
                        state.setText("비콘" + " " + uuid + " " + "송신중");
                        beaconTransmitter.stopAdvertising();
                    }
                } catch (Exception e) {
                    //    Toast myToast = Toast.makeText(getApplicationContext(),"올바른 Major, Minor를 입력하시오", Toast.LENGTH_SHORT);
                    //   myToast.show();
                }

                this.sendEmptyMessageDelayed(0, tx_inter);
                Log.e("aa", "msggg");
            }
        };

        final Handler t_handler = new Handler() {

            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                Log.e("beacon", "undoing advertising");
                if (t < 100) {
                    try {
                        beacon = new Beacon.Builder()
                                .setId1(uuid)//uuid 8-4-4-4-12
                                .setId2(major_v)
                                .setId3(minor_v)
                                .setManufacturer(0x0118) // Radius Networks.  Change this for other beacon layouts  ibeacon setup
                                .setTxPower(TxPower)  //-59 -65 -69 -72 -77 -81 -84 -115
                                .setDataFields(Arrays.asList(new Long[]{0l})) // Remove this for beacon layouts without d: fields
                                .build();
                        beaconParser = new BeaconParser()
                                .setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24");  //포맷 중요
                        beaconTransmitter = new BeaconTransmitter(getApplicationContext(), beaconParser);
                        if (beaconTransmitter.isStarted() == true) {
                            beaconTransmitter.startAdvertising(beacon, new AdvertiseCallback() {
                                @Override
                                public void onStartFailure(int errorCode) {
                                    Log.e("", "Advertisement start failed with code: " + errorCode);
                                }

                                @Override
                                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                                    Log.i("", "Advertisement start succeeded.");
                                }
                            });
                            major_v = Major.getText().toString();
                            minor_v = Minor.getText().toString();
                            Major.setText("Major : " + major_v);
                            Minor.setText("Minor : " + minor_v);
                            state.setText("비콘송신중");

                        } else {
                            beaconTransmitter.startAdvertising(beacon, new AdvertiseCallback() {
                                @Override
                                public void onStartFailure(int errorCode) {
                                    Log.e("", "Advertisement start failed with code: " + errorCode);
                                }

                                @Override
                                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                                    Log.i("", "Advertisement start succeeded.");
                                }
                            });

                            major_v = Major.getText().toString();
                            minor_v = Minor.getText().toString();
                            Major.setText(major_v);
                            Minor.setText(minor_v);
                            state.setTextSize(12);
                            state.setText("비콘" + " " + uuid + " " + "송신중");
                            beaconTransmitter.stopAdvertising();
                        }
                    } catch (Exception e) {
                        //    Toast myToast = Toast.makeText(getApplicationContext(),"올바른 Major, Minor를 입력하시오", Toast.LENGTH_SHORT);
                        //   myToast.show();
                    }

                    this.sendEmptyMessageDelayed(0, tx_inter);
                    t++;
                } else {
                    Toast t_Toast = Toast.makeText(getApplicationContext(), "100번 완료", Toast.LENGTH_SHORT);
                    t_Toast.show();
                }
            }
        };


        tx_interval.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    tx_interval.setText("");
                    String t_in = tx_interval.getText().toString();
                    tx_inter = Integer.parseInt(t_in);
                } catch (Exception e) {
                }
            }
        });

        Major.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Major.setText("");
            }
        });
        Minor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Minor.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Minor.setText("");
                    }
                });
            }
        });
        //once
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("beacon", "start advertising");
                state.setText("지속적 송신중");


                handler.sendEmptyMessage(0);
            }
        });

        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("beacon", "test advertising");
                state.setText("테스트 송신");
                t_handler.sendEmptyMessage(0);
            }

        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("beacon", "stop advertising");
                handler.removeMessages(0);
                state.setText("대기중");
            }
        });


        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Txbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String[] items = new String[]{"-59dBm      70m ", "-65dBm      60m", "-69dBm      40m", "-72dBm      30m", "-77dBm      20m", "-81dBm      10m", "-84dBm       4m", "-115dBm     2m"};
                final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("TxPower");
                dialog.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                TxPower = -59;
                                break;
                            case 1:
                                TxPower = -65;
                                break;
                            case 2:
                                TxPower = -69;
                                break;
                            case 3:
                                TxPower = -72;
                                break;
                            case 4:
                                TxPower = -77;
                                break;
                            case 5:
                                TxPower = -81;
                                break;
                            case 6:
                                TxPower = -84;
                                break;
                            case 7:
                                TxPower = -115;
                                break;
                        }
                    }
                });

                dialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });

                dialog.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.e("s", "" + TxPower);
                        s_tx.setText(TxPower + "dBm");
                    }
                });
                dialog.create();
                dialog.show();
            }
        });
    }
}
